declare module 'mysql-promise';
declare module 'file-type';
declare module 'node-fetch';